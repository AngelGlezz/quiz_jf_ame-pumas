<?php
	$metas = array(
		"america" => array(
			"title" => "¿Pumas o América?",
			"description" => "!Eres un maestro del control! No lo esperaba. Te rifas tanto como Pogba",
			"image" => "images/respuestas/america.jpg" 
		),
		"neutro" => array(
			"title" => "¿Pumas o América?",
			"description" => "Lo tuyo lo tuyo es hacer que lo imposible suceda. Messi te querría seguro en su equipo",
			"image" => "images/respuestas/neutro.jpg" 
		),
		"pumas" => array(
			"title" => "¿Pumas o América?",
			"description" => "¡Un Luis Suáres en su máxima potencia! Corres, luchas, recuperas y metes goles, nadie te detiene.",
			"image" => "images/respuestas/pumas.jpg" 
		),
	);